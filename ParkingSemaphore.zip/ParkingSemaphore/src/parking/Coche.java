package parking;

import java.util.concurrent.ThreadLocalRandom;

/*** Tarea concurrente "Coche".
 * Intenta entrar, permanece un tiempo aleatorio simulando que está aparcado y luego sale.*/

public class Coche implements Runnable {

    private final String nombre;
    private final Aparcamiento aparcamiento;

    /*** @param nombre identificador legible para las trazas.
     * @param aparcamiento referencia compartida al recurso a usar.*/
    public Coche(String nombre, Aparcamiento aparcamiento) {
        this.nombre = nombre;
        this.aparcamiento = aparcamiento;
    }

    /*** Protocolo de uso correcto del recurso:
     * - entrar()
     * - trabajar (simular aparcado)
     * - salir()
     * Se usa try/finally para asegurar la salida incluso si hay excepciones en el "trabajo".*/

    @Override
    public void run() {
        try {
            aparcamiento.entrar(nombre);

            // Simula el tiempo que la plaza está ocupada: 1 a 4 segundos.
            int ms = ThreadLocalRandom.current().nextInt(1_000, 4_001);
            Thread.sleep(ms);

        } catch (InterruptedException e) {
            // Si el hilo es interrumpido, reestablecemos el estado de interrupción.
            Thread.currentThread().interrupt();
        } finally {
            // Garantiza liberar la plaza.
            aparcamiento.salir(nombre);
        }
    }
}
