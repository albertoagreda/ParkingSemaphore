package parking;

import java.util.ArrayList;
import java.util.List;

/*** Punto de entrada del programa.
 * Crea un aparcamiento de 3 plazas y lanza 7 hilos "Coche".*/

public class PrincipalParking {

    public static void main(String[] args) {
        // Capacidad simultánea requerida por el enunciado: 3
        Aparcamiento aparcamiento = new Aparcamiento(3);

        // Crear 7 coches
        List<Thread> hilos = new ArrayList<>();
        for (int i = 1; i <= 7; i++) {
            Coche tarea = new Coche("Coche-" + i, aparcamiento);
            Thread hilo = new Thread(tarea, "HILO-" + i);
            hilos.add(hilo);
        }

        // Arrancar hilos
        hilos.forEach(Thread::start);

        // Esperar a que todos terminen
        for (Thread h : hilos) {
            try {
                h.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                // Si principal es interrumpido, salimos del bucle.
                break;
            }
        }

        System.out.println("Simulación finalizada.");
    }
}
