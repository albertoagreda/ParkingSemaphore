package parking;

import java.util.concurrent.Semaphore;

/*** Recurso compartido "Aparcamiento".
 * Controla un número finito de plazas usando java.util.concurrent.Semaphore.
 * Regla de negocio: como máximo 'capacidad' coches dentro a la vez.*/

public class Aparcamiento {

    // Semáforo con 'capacidad' permisos.
    // Modo justo (fair=true) intenta atender a los hilos en orden de llegada para evitar inanición.
    private final Semaphore semaforo;

    // Contador informativo de plazas ocupadas (solo para logs). Se protege con 'synchronized'.
    private int ocupadas = 0;

    /*** Crea un aparcamiento con capacidad fija.
     * @param capacidad número máximo de coches simultáneos.*/

    public Aparcamiento(int capacidad) {
        this.semaforo = new Semaphore(capacidad, true);
    }

    /*** Entrada al aparcamiento. Bloquea si no hay plazas libres.
     * Flujo:
     * 1) acquire() reserva 1 permiso del semáforo (puede bloquear).
     * 2) sección crítica para actualizar contador y loguear el estado.
     *
     * @param nombreCoche etiqueta para trazas.
     * @throws InterruptedException si el hilo es interrumpido mientras espera.*/

    public void entrar(String nombreCoche) throws InterruptedException {
        log(nombreCoche + " quiere entrar");
        semaforo.acquire(); // Bloquea hasta que haya permiso.

        synchronized (this) {
            ocupadas++;
            log(nombreCoche + " ha ENTRADO. Ocupadas=" + ocupadas + " | Libres=" + semaforo.availablePermits());
        }
    }

    /*** Salida del aparcamiento. Libera una plaza.
     * Flujo:
     * 1) sección crítica para decrementar contador y loguear.
     * 2) release() devuelve el permiso al semáforo.
     *
     * @param nombreCoche etiqueta para trazas.*/

    public void salir(String nombreCoche) {
        synchronized (this) {
            // Defensa básica ante errores lógicos externos: nunca negativo.
            if (ocupadas > 0) ocupadas--;
            log(nombreCoche + " ha SALIDO. Ocupadas=" + ocupadas + " | Libres=" + semaforo.availablePermits());
        }
        semaforo.release();
    }

    // Utilidad de logging con timestamp e hilo actual.
    private void log(String msg) {
        System.out.printf("[%d][%s] %s%n",
                System.currentTimeMillis(),
                Thread.currentThread().getName(),
                msg);
    }
}
